import './style.css'
import { setupCounter } from './counter.js'
import taskList from './data/mockData';
import mockLists from './data/mockData';

console.log(mockLists);

const appContainer = document.getElementById('app');

function renderLists() {
  appContainer.innerHTML = '';
  mockLists.forEach(list => {
    const listContainer = document.createElement('div');
    listContainer.classList.add('list-container');

    const listTitle = document.createElement('h2');
    listTitle.textContent = list.title;

    const taskList = document.createElement('ul');
    taskList.classList.add('task-list');

  list.tasks.forEach(task => {
    const taskItem = document.createElement('li');
    taskItem.classList.add('task-item');
    if (task.completed) {
      taskItem.classList.add('completed');
    }

  const taskCheckbox = document.createElement('input');
  taskCheckbox.type = 'checkbox';
  taskCheckbox.checked = task.completed;

  const taskText = document.createElement('span');
  taskText.textContent = task.text;

  taskItem.appendChild(taskCheckbox);
  taskItem.appendChild(taskText);
  taskList.appendChild(taskItem);
    });

listContainer.appendChild(listTitle);
listContainer.appendChild(taskList);

appContainer.appendChild(listContainer);
});
}
renderLists();

const form = document.getElementById('addTaskForm');
const taskInput = document.getElementById('taskInput');

form.addEventListener('submit', (event) => {
  event.preventDefault();
  const newTaskText = taskInput.value.trim();
  if (newTaskText !== '') {
    const firstList = mockLists[0];
    const newTask = {
      id: `task-${Date.now()}`,
      text: newTaskText,
      completed: false,
    };
    firstList.tasks.push(newTask);
    renderLists();
    taskInput.value = '';
  }
});

appContainer.innerHTML = `
  <h1>Mis Listas de Tareas</h1>
  ${mockLists.map(list => `
    <div class="list-container">
      <h2>${list.title}</h2>
      <ul class="task-list">
        ${list.tasks.map(task => `
          <li class="task-item ${task.completed ? 'completed' : ''}">
            <input type="checkbox" ${task.completed ? 'checked' : ''} />
            ${task.text}
          </li>
        `).join('')}
      </ul>
    </div>
  `).join('')}
`

setupCounter(document.querySelector('#counter'))
